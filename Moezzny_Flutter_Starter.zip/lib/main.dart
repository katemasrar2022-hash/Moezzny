import 'package:flutter/material.dart';
void main() => runApp(const MoezznyApp());
const navy = Color(0xFF101B35);
const gold = Color(0xFFD9B66D);
void msg(BuildContext c, String s) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(s)));
class MoezznyApp extends StatelessWidget {
 const MoezznyApp({super.key});
 @override Widget build(BuildContext context) => MaterialApp(
  title:'مؤذني', debugShowCheckedModeBanner:false,
  theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:navy),scaffoldBackgroundColor:const Color(0xFFF7F4EC)),
  home:const Home());
}
class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home> {
 int tab=0;
 final names=['الرئيسية','القرآن','الأذكار','القبلة','الإعدادات'];
 final icons=[Icons.home_rounded,Icons.menu_book_rounded,Icons.spa_rounded,Icons.explore_rounded,Icons.settings_rounded];
 @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
 appBar:AppBar(backgroundColor:navy,foregroundColor:Colors.white,title:const Row(children:[Icon(Icons.mosque,color:gold),SizedBox(width:10),Text('مؤذني',style:TextStyle(fontWeight:FontWeight.bold))])),
 body:IndexedStack(index:tab,children:[home(),page('القرآن الكريم',Icons.menu_book,'قسم القراءة والتلاوات سيُستكمل في المرحلة التالية.'),page('الأذكار والسبحة',Icons.spa,'الأذكار والعداد وحفظ التقدم ستُضاف لاحقًا.'),page('اتجاه القبلة',Icons.explore,'الموقع والبوصلة يحتاجان إلى تفعيل الصلاحيات والحساب.'),page('الإعدادات',Icons.settings,'إعداد المدينة والمواقيت والتنبيهات.')]),
 bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:List.generate(names.length,(i)=>NavigationDestination(icon:Icon(icons[i]),label:names[i])))));
 Widget home()=>ListView(padding:const EdgeInsets.all(16),children:[
 Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(24)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 Text('السلام عليكم ورحمة الله وبركاته',style:TextStyle(color:Colors.white70)),SizedBox(height:12),
 Text('حان وقت الطمأنينة',style:TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),SizedBox(height:8),
 Row(children:[Icon(Icons.location_on_outlined,color:gold),SizedBox(width:5),Text('اختر مدينتك من الإعدادات',style:TextStyle(color:Colors.white70))]),SizedBox(height:20),
 Divider(color:Colors.white24),Text('الصلاة القادمة',style:TextStyle(color:Colors.white70)),SizedBox(height:5),
 Row(children:[Text('الفجر',style:TextStyle(color:gold,fontSize:23,fontWeight:FontWeight.bold)),Spacer(),Text('--:--',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.bold))]),
 Text('سيظهر العد التنازلي بعد تفعيل حساب المواقيت',style:TextStyle(color:Colors.white60,fontSize:12))])),
 const SizedBox(height:20),const Text('مواقيت الصلاة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:navy)),const SizedBox(height:10),
 ...[('الفجر','--:--',Icons.nights_stay),('الشروق','--:--',Icons.wb_twilight),('الظهر','--:--',Icons.wb_sunny),('العصر','--:--',Icons.sunny),('المغرب','--:--',Icons.wb_twilight),('العشاء','--:--',Icons.dark_mode)].map((p)=>Card(color:Colors.white,elevation:0,child:ListTile(leading:CircleAvatar(backgroundColor:gold.withValues(alpha:.2),child:Icon(p.$3,color:navy)),title:Text(p.$1),trailing:Text(p.$2,style:const TextStyle(fontWeight:FontWeight.bold,color:navy)),onTap:()=>msg(context,'سيتم ربط مواقيت الصلاة بالحساب الفعلي لاحقًا.')))),
 const SizedBox(height:12),const Text('خدمات مؤذني',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:navy)),const SizedBox(height:10),
 GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:1.7,children:const [_Tile(Icons.menu_book,'القرآن الكريم'),_Tile(Icons.spa,'الأذكار والسبحة'),_Tile(Icons.explore,'اتجاه القبلة'),_Tile(Icons.calendar_month,'التقويم الهجري')]),
 const SizedBox(height:12),const Text('نسخة تأسيسية: لم يتم تفعيل الموقع أو الأذان بعد.',style:TextStyle(color:Colors.black54,fontSize:12))]);
 Widget page(String title,IconData icon,String desc)=>Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:60,color:gold),const SizedBox(height:16),Text(title,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:navy)),const SizedBox(height:10),Text(desc,textAlign:TextAlign.center,style:const TextStyle(height:1.6))])));
}
class _Tile extends StatelessWidget { final IconData icon; final String title; const _Tile(this.icon,this.title); @override Widget build(BuildContext c)=>Card(color:Colors.white,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:navy,size:28),const SizedBox(height:8),Text(title,style:const TextStyle(color:navy,fontWeight:FontWeight.w600))]));}
